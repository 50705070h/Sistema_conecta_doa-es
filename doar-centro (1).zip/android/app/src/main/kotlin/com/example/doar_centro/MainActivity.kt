package com.example.doar_centro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
