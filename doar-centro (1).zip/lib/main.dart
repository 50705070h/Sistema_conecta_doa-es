import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

void main() {
  runApp(const ConectaDoacoes());
}

const Color verde = Color(0xFF2E7D32);
const Color verdeClaro = Color(0xFFE8F5E9);

// APLICATIVO

class ConectaDoacoes extends StatelessWidget {
  const ConectaDoacoes({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Conecta Doações',
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.white,
      ),
      home: const TelaLogin(),
    );
  }
}

// TELA DE LOGIN

class TelaLogin extends StatefulWidget {
  const TelaLogin({super.key});

  @override
  State<TelaLogin> createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  final emailController = TextEditingController();
  final senhaController = TextEditingController();

  bool mostrarSenha = false;
  String tipoUsuario = 'Doador';

  void entrar() {
    if (emailController.text.trim().isEmpty || senhaController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Preencha todos os campos!'),
        ),
      );
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (context) => TelaInicial(
          emailUsuario: emailController.text.trim(),
          tipoUsuario: tipoUsuario,
        ),
      ),
    );
  }

  @override
  void dispose() {
    emailController.dispose();
    senhaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(25),
          child: Column(
            children: [
              const Icon(
                Icons.volunteer_activism,
                size: 90,
                color: verde,
              ),
              const SizedBox(height: 15),
              const Text(
                'Conecta Doações',
                style: TextStyle(
                  fontSize: 29,
                  fontWeight: FontWeight.bold,
                  color: verde,
                ),
              ),
              const SizedBox(height: 10),
              const Text(
                'Conectando pessoas e transformando vidas!',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 35),
              TextField(
                controller: emailController,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(
                  labelText: 'E-mail',
                  prefixIcon: Icon(Icons.email),
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              TextField(
                controller: senhaController,
                obscureText: !mostrarSenha,
                decoration: InputDecoration(
                  labelText: 'Senha',
                  prefixIcon: const Icon(Icons.lock),
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(
                      mostrarSenha ? Icons.visibility_off : Icons.visibility,
                    ),
                    onPressed: () {
                      setState(() {
                        mostrarSenha = !mostrarSenha;
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 18),
              const Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Entrar como:',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                ),
              ),
              RadioListTile<String>(
                contentPadding: EdgeInsets.zero,
                title: const Text('Doador'),
                value: 'Doador',
                groupValue: tipoUsuario,
                activeColor: verde,
                onChanged: (valor) {
                  setState(() => tipoUsuario = valor!);
                },
              ),
              RadioListTile<String>(
                contentPadding: EdgeInsets.zero,
                title: const Text('Centro Comunitário'),
                value: 'Centro Comunitário',
                groupValue: tipoUsuario,
                activeColor: verde,
                onChanged: (valor) {
                  setState(() => tipoUsuario = valor!);
                },
              ),
              const SizedBox(height: 10),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: entrar,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: verde,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Entrar'),
                ),
              ),
              const SizedBox(height: 15),
              TextButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => const TelaCadastro(),
                    ),
                  );
                },
                child: const Text(
                  'Não tem uma conta? Cadastre-se',
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// TELA DE CADASTRO

class TelaCadastro extends StatefulWidget {
  const TelaCadastro({super.key});

  @override
  State<TelaCadastro> createState() => _TelaCadastroState();
}

class _TelaCadastroState extends State<TelaCadastro> {
  final nomeController = TextEditingController();
  final emailController = TextEditingController();
  final telefoneController = TextEditingController();
  final senhaController = TextEditingController();

  String tipoUsuario = 'Doador';

  @override
  void dispose() {
    nomeController.dispose();
    emailController.dispose();
    telefoneController.dispose();
    senhaController.dispose();
    super.dispose();
  }

  void cadastrar() {
    if (nomeController.text.trim().isEmpty ||
        emailController.text.trim().isEmpty ||
        telefoneController.text.trim().isEmpty ||
        senhaController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Preencha todos os campos!'),
        ),
      );
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Cadastro demonstrativo realizado!'),
      ),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Criar conta'),
        backgroundColor: verde,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(
              Icons.person_add_alt_1,
              size: 65,
              color: verde,
            ),
            const SizedBox(height: 20),
            TextField(
              controller: nomeController,
              decoration: const InputDecoration(
                labelText: 'Nome completo',
                prefixIcon: Icon(Icons.person),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(
                labelText: 'E-mail',
                prefixIcon: Icon(Icons.email),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: telefoneController,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText: 'Telefone',
                prefixIcon: Icon(Icons.phone),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 15),
            TextField(
              controller: senhaController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: 'Senha',
                prefixIcon: Icon(Icons.lock),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Tipo de cadastro:',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            RadioListTile<String>(
              title: const Text('Doador'),
              value: 'Doador',
              groupValue: tipoUsuario,
              activeColor: verde,
              onChanged: (valor) {
                setState(() {
                  tipoUsuario = valor!;
                });
              },
            ),
            RadioListTile<String>(
              title: const Text('Centro Comunitário'),
              value: 'Centro Comunitário',
              groupValue: tipoUsuario,
              activeColor: verde,
              onChanged: (valor) {
                setState(() {
                  tipoUsuario = valor!;
                });
              },
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              height: 50,
              child: ElevatedButton(
                onPressed: cadastrar,
                style: ElevatedButton.styleFrom(
                  backgroundColor: verde,
                  foregroundColor: Colors.white,
                ),
                child: const Text('Cadastrar'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// TELA INICIAL

class TelaInicial extends StatefulWidget {
  final String emailUsuario;
  final String tipoUsuario;

  const TelaInicial({
    super.key,
    required this.emailUsuario,
    required this.tipoUsuario,
  });

  @override
  State<TelaInicial> createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {
  int paginaSelecionada = 0;

  final List<Map<String, dynamic>> doacoes = [
    {
      'nome': 'Roupas para doação',
      'categoria': 'Roupas',
      'descricao': 'Roupas em bom estado para adultos e crianças.',
      'imagem': null,
    },
    {
      'nome': 'Cesta de alimentos',
      'categoria': 'Alimentos',
      'descricao': 'Alimentos não perecíveis para famílias.',
      'imagem': null,
    },
    {
      'nome': 'Livros usados',
      'categoria': 'Livros',
      'descricao': 'Livros para incentivar a leitura.',
      'imagem': null,
    },
    {
      'nome': 'Brinquedos infantis',
      'categoria': 'Brinquedos',
      'descricao': 'Brinquedos conservados para crianças.',
      'imagem': null,
    },
  ];

  Future<void> abrirPublicacao() async {
    final novaDoacao = await Navigator.push<Map<String, dynamic>>(
      context,
      MaterialPageRoute(
        builder: (context) => const TelaPublicarDoacao(),
      ),
    );

    if (!mounted) return;

    if (novaDoacao != null) {
      setState(() {
        doacoes.insert(0, novaDoacao);
        paginaSelecionada = 1;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Doação publicada com sucesso!'),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final paginas = [
      construirInicio(),
      construirDoacoes(),
      construirPerfil(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Conecta Doações',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: verde,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications),
            onPressed: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Você não possui notificações.'),
                ),
              );
            },
          ),
        ],
      ),
      body: paginas[paginaSelecionada],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: paginaSelecionada,
        selectedItemColor: verde,
        onTap: (indice) {
          setState(() {
            paginaSelecionada = indice;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Início',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.volunteer_activism),
            label: 'Doações',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Perfil',
          ),
        ],
      ),
    );
  }

  Widget construirInicio() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Olá! Seja bem-vindo(a) 👋',
            style: TextStyle(
              fontSize: 23,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Juntos podemos fazer a diferença na vida de alguém.',
            style: TextStyle(
              color: Colors.black54,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: verdeClaro,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Faça parte dessa corrente do bem!',
                  style: TextStyle(
                    fontSize: 19,
                    fontWeight: FontWeight.bold,
                    color: verde,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Compartilhe o que você não usa mais e ajude quem precisa.',
                ),
                const SizedBox(height: 15),
                ElevatedButton.icon(
                  onPressed: abrirPublicacao,
                  icon: const Icon(Icons.add),
                  label: const Text('Publicar doação'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: verde,
                    foregroundColor: Colors.white,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 25),
          const Text(
            'Categorias',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 15),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: const [
              CategoriaCard(
                icone: Icons.checkroom,
                nome: 'Roupas',
              ),
              CategoriaCard(
                icone: Icons.restaurant,
                nome: 'Alimentos',
              ),
              CategoriaCard(
                icone: Icons.menu_book,
                nome: 'Livros',
              ),
              CategoriaCard(
                icone: Icons.toys,
                nome: 'Brinquedos',
              ),
            ],
          ),
          const SizedBox(height: 20),
          const Text(
            'Doações disponíveis',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          ...doacoes.take(3).map(
                (doacao) => CardDoacao(doacao: doacao),
              ),
        ],
      ),
    );
  }

  Widget construirDoacoes() {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Doações disponíveis',
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.bold,
                ),
              ),
              IconButton(
                onPressed: abrirPublicacao,
                icon: const Icon(
                  Icons.add_circle,
                  color: verde,
                  size: 30,
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: doacoes.isEmpty
              ? const Center(
                  child: Text('Nenhuma doação disponível.'),
                )
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                  ),
                  itemCount: doacoes.length,
                  itemBuilder: (context, index) {
                    return CardDoacao(
                      doacao: doacoes[index],
                    );
                  },
                ),
        ),
      ],
    );
  }

  Widget construirPerfil() {
    if (widget.tipoUsuario == 'Centro Comunitário') {
      return construirPerfilCentro();
    }
    return construirPerfilDoador();
  }

  // PERFIL PERSONALIZADO DO CENTRO COMUNITÁRIO
  Widget construirPerfilCentro() {
    const azulCentro = Color(0xFF1565C0);
    const azulClaroCentro = Color(0xFFE3F2FD);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [Color(0xFF1565C0), Color(0xFF42A5F5)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 42,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.apartment, size: 48, color: azulCentro),
                ),
                const SizedBox(height: 12),
                const Text(
                  'Painel do Centro Comunitário',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  widget.emailUsuario,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white70),
                ),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 7,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Text(
                    'CENTRO COMUNITÁRIO',
                    style: TextStyle(
                      color: azulCentro,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            'Resumo da instituição',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Card(
            elevation: 1,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: azulClaroCentro,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.volunteer_activism,
                      color: azulCentro,
                      size: 30,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${doacoes.length}',
                          style: const TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: azulCentro,
                          ),
                        ),
                        const Text('Doações disponíveis na plataforma'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            'O que deseja fazer?',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              contentPadding: const EdgeInsets.all(12),
              leading: const CircleAvatar(
                backgroundColor: azulClaroCentro,
                child: Icon(Icons.search, color: azulCentro),
              ),
              title: const Text(
                'Encontrar doações',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: const Text(
                'Veja roupas, alimentos, livros e outros itens disponíveis.',
              ),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                setState(() => paginaSelecionada = 1);
              },
            ),
          ),
          Card(
            child: ListTile(
              contentPadding: const EdgeInsets.all(12),
              leading: const CircleAvatar(
                backgroundColor: azulClaroCentro,
                child: Icon(Icons.account_balance, color: azulCentro),
              ),
              title: const Text(
                'Dados da instituição',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(widget.emailUsuario),
            ),
          ),
          const SizedBox(height: 22),
          const Text(
            'Doações que podem ajudar sua comunidade',
            style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 10),
          ...doacoes.take(3).map((doacao) => CardDoacao(doacao: doacao)),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('Sair da conta'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: confirmarSaida,
            ),
          ),
        ],
      ),
    );
  }

  // PERFIL DO DOADOR
  Widget construirPerfilDoador() {
    final minhasDoacoes =
        doacoes.where((doacao) => doacao['minhaDoacao'] == true).toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          const SizedBox(height: 10),
          CircleAvatar(
            radius: 48,
            backgroundColor: verdeClaro,
            child: Icon(
              widget.tipoUsuario == 'Centro Comunitário'
                  ? Icons.apartment
                  : Icons.person,
              size: 55,
              color: verde,
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'Meu Perfil',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 6),
          Text(
            widget.emailUsuario,
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.black54),
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
            decoration: BoxDecoration(
              color: verdeClaro,
              borderRadius: BorderRadius.circular(20),
            ),
            child: Text(
              widget.tipoUsuario,
              style: const TextStyle(
                color: verde,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.volunteer_activism, color: verde, size: 30),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${minhasDoacoes.length}',
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          color: verde,
                        ),
                      ),
                      const Text('Doações publicadas'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Minhas publicações',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 10),
          if (minhasDoacoes.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Row(
                  children: [
                    Icon(Icons.info_outline, color: verde),
                    SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        'Você ainda não publicou nenhuma doação.',
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            ...minhasDoacoes.map(
              (doacao) => CardDoacao(doacao: doacao),
            ),
          const SizedBox(height: 20),
          Card(
            child: ListTile(
              leading: const Icon(Icons.person_outline, color: verde),
              title: const Text('Dados da conta'),
              subtitle: Text(widget.emailUsuario),
            ),
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const Icon(Icons.logout, color: Colors.red),
              title: const Text('Sair da conta'),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                showDialog(
                  context: context,
                  builder: (dialogContext) => AlertDialog(
                    title: const Text('Sair da conta?'),
                    content: const Text(
                      'Deseja realmente voltar para a tela de login?',
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(dialogContext),
                        child: const Text('Cancelar'),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pop(dialogContext);
                          Navigator.pushAndRemoveUntil(
                            context,
                            MaterialPageRoute(
                              builder: (context) => const TelaLogin(),
                            ),
                            (route) => false,
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: verde,
                          foregroundColor: Colors.white,
                        ),
                        child: const Text('Sair'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void confirmarSaida() {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Sair da conta?'),
        content: const Text('Deseja realmente voltar para a tela de login?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(dialogContext);
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const TelaLogin()),
                (route) => false,
              );
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: verde,
              foregroundColor: Colors.white,
            ),
            child: const Text('Sair'),
          ),
        ],
      ),
    );
  }
}

// CARD DE CATEGORIA

class CategoriaCard extends StatelessWidget {
  final IconData icone;
  final String nome;

  const CategoriaCard({
    super.key,
    required this.icone,
    required this.nome,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CircleAvatar(
          radius: 27,
          backgroundColor: verdeClaro,
          child: Icon(
            icone,
            color: verde,
            size: 27,
          ),
        ),
        const SizedBox(height: 7),
        Text(
          nome,
          style: const TextStyle(fontSize: 11),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}

// CARD DE DOAÇÃO

class CardDoacao extends StatelessWidget {
  final Map<String, dynamic> doacao;

  const CardDoacao({
    super.key,
    required this.doacao,
  });

  @override
  Widget build(BuildContext context) {
    final Uint8List? imagem = doacao['imagem'] as Uint8List?;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      child: ListTile(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => TelaDetalhesDoacao(doacao: doacao),
            ),
          );
        },
        leading: imagem != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.memory(
                  imagem,
                  width: 65,
                  height: 65,
                  fit: BoxFit.cover,
                ),
              )
            : const CircleAvatar(
                backgroundColor: verdeClaro,
                child: Icon(
                  Icons.volunteer_activism,
                  color: verde,
                ),
              ),
        title: Text(
          doacao['nome'] ?? '',
          style: const TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: Text(
          '${doacao['categoria']}\n${doacao['descricao']}',
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        trailing: const Icon(
          Icons.arrow_forward_ios,
          size: 16,
        ),
      ),
    );
  }
}

// TELA DE PUBLICAÇÃO

class TelaPublicarDoacao extends StatefulWidget {
  const TelaPublicarDoacao({super.key});

  @override
  State<TelaPublicarDoacao> createState() => _TelaPublicarDoacaoState();
}

class _TelaPublicarDoacaoState extends State<TelaPublicarDoacao> {
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  String categoriaSelecionada = 'Roupas';

  Uint8List? imagemSelecionada;

  final ImagePicker picker = ImagePicker();

  final categorias = [
    'Roupas',
    'Alimentos',
    'Livros',
    'Brinquedos',
    'Móveis',
    'Eletrônicos',
    'Outros',
  ];

  Future<void> selecionarImagem() async {
    try {
      final XFile? imagem = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 80,
      );

      if (imagem != null) {
        final bytes = await imagem.readAsBytes();

        if (!mounted) return;

        setState(() {
          imagemSelecionada = bytes;
        });
      }
    } catch (e) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Não foi possível selecionar a foto: $e',
          ),
        ),
      );
    }
  }

  void publicar() {
    if (nomeController.text.trim().isEmpty ||
        descricaoController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Preencha o nome e a descrição da doação!',
          ),
        ),
      );
      return;
    }

    final novaDoacao = <String, dynamic>{
      'nome': nomeController.text.trim(),
      'categoria': categoriaSelecionada,
      'descricao': descricaoController.text.trim(),
      'imagem': imagemSelecionada,
      'minhaDoacao': true,
    };

    Navigator.pop(context, novaDoacao);
  }

  @override
  void dispose() {
    nomeController.dispose();
    descricaoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Publicar doação'),
        backgroundColor: verde,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Center(
              child: Icon(
                Icons.volunteer_activism,
                color: verde,
                size: 75,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Compartilhe uma doação',
              style: TextStyle(
                fontSize: 23,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Informe os detalhes do item que deseja doar.',
              style: TextStyle(color: Colors.black54),
            ),
            const SizedBox(height: 25),
            TextField(
              controller: nomeController,
              decoration: const InputDecoration(
                labelText: 'Nome do item',
                hintText: 'Ex.: Roupas infantis',
                prefixIcon: Icon(Icons.inventory_2),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 20),
            DropdownButtonFormField<String>(
              value: categoriaSelecionada,
              decoration: const InputDecoration(
                labelText: 'Categoria',
                prefixIcon: Icon(Icons.category),
                border: OutlineInputBorder(),
              ),
              items: categorias.map((categoria) {
                return DropdownMenuItem<String>(
                  value: categoria,
                  child: Text(categoria),
                );
              }).toList(),
              onChanged: (valor) {
                if (valor != null) {
                  setState(() {
                    categoriaSelecionada = valor;
                  });
                }
              },
            ),
            const SizedBox(height: 20),
            TextField(
              controller: descricaoController,
              maxLines: 5,
              decoration: const InputDecoration(
                labelText: 'Descrição da doação',
                hintText: 'Descreva o estado e os detalhes do item...',
                alignLabelWithHint: true,
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 25),
            const Text(
              'Foto do produto',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            const SizedBox(height: 10),
            GestureDetector(
              onTap: selecionarImagem,
              child: Container(
                width: double.infinity,
                height: 190,
                decoration: BoxDecoration(
                  color: verdeClaro,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: verde),
                ),
                child: imagemSelecionada != null
                    ? ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.memory(
                          imagemSelecionada!,
                          width: double.infinity,
                          fit: BoxFit.cover,
                        ),
                      )
                    : const Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.add_a_photo,
                            size: 50,
                            color: verde,
                          ),
                          SizedBox(height: 10),
                          Text(
                            'Toque para escolher uma foto',
                            style: TextStyle(color: verde),
                          ),
                        ],
                      ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: selecionarImagem,
                icon: const Icon(Icons.photo_library),
                label: const Text(
                  'Selecionar foto da galeria',
                ),
                style: OutlinedButton.styleFrom(
                  foregroundColor: verde,
                ),
              ),
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton.icon(
                onPressed: publicar,
                icon: const Icon(Icons.check),
                label: const Text('Publicar doação'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: verde,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// TELA DE DETALHES DA DOAÇÃO

class TelaDetalhesDoacao extends StatelessWidget {
  final Map<String, dynamic> doacao;

  const TelaDetalhesDoacao({
    super.key,
    required this.doacao,
  });

  void demonstrarInteresse(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Interesse registrado!'),
          content: const Text(
            'Seu interesse nesta doação foi registrado '
            'neste protótipo. Entre em contato com o doador '
            'para combinar os detalhes.',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                Navigator.pop(context);
              },
              child: const Text(
                'Entendi',
                style: TextStyle(color: verde),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final Uint8List? imagem = doacao['imagem'] as Uint8List?;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Detalhes da doação'),
        backgroundColor: verde,
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // FOTO

            Container(
              width: double.infinity,
              height: 250,
              decoration: BoxDecoration(
                color: verdeClaro,
                borderRadius: BorderRadius.circular(15),
              ),
              child: imagem != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.memory(
                        imagem,
                        fit: BoxFit.cover,
                      ),
                    )
                  : const Icon(
                      Icons.volunteer_activism,
                      color: verde,
                      size: 90,
                    ),
            ),

            const SizedBox(height: 25),

            // NOME

            Text(
              doacao['nome'] ?? '',
              style: const TextStyle(
                fontSize: 25,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 15),

            // CATEGORIA

            Row(
              children: [
                const Icon(
                  Icons.category,
                  color: verde,
                ),
                const SizedBox(width: 10),
                Text(
                  doacao['categoria'] ?? '',
                  style: const TextStyle(fontSize: 16),
                ),
              ],
            ),

            const SizedBox(height: 25),

            const Text(
              'Descrição do item',
              style: TextStyle(
                fontSize: 19,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            Text(
              doacao['descricao'] ?? '',
              style: const TextStyle(
                fontSize: 16,
                height: 1.5,
              ),
            ),

            const SizedBox(height: 35),

            // BOTÃO DE INTERESSE

            SizedBox(
              width: double.infinity,
              height: 55,
              child: ElevatedButton.icon(
                onPressed: () {
                  demonstrarInteresse(context);
                },
                icon: const Icon(Icons.favorite),
                label: const Text(
                  'Tenho interesse nesta doação',
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: verde,
                  foregroundColor: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
